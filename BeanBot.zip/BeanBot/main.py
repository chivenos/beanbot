#------------------------------------------------------------------------------------------#
#Written by chivenos
#Source code https://github.com/chivenos/beanbot
#Discord chivenos#5890
#E-mail chivenosthedev@gmail.com
#Feel free to use for any purpose
#------------------------------------------------------------------------------------------#


import discord
from discord.ext import commands
from discord.utils import get
import json
from datetime import datetime
import asyncio
from themes import ReturnRandomTheme


token = "YOUR TOKEN" #Replace your token
defaultPrefix = "bb"
beanJamCount = 5
statusLoopInterval = 5
beanJamNotificationsLoopInterval = 60
embedColor = discord.Colour.green()
botCredits = "chivenos#5890\nDiscord Server: https://discord.gg/8jcNWqeQgQ"
beanJamStartDate = [6,14,0] #week day, hour, minute (GMT)
beanJamThemeDate = [6,13,40] #week day, hour, minute (GMT)
beanJamReminderDate = [6,13,0] #week day, hour, minute (GMT)
beanJamRoleDate = [1,14,0] #week day, hour, minute (GMT)


def get_prefix(client, message):
    with open("data.json", "r") as f:
        data = json.load(f)

    return data["prefixes"][str(message.guild.id)]


def GetAvatarLink(link):
    return link[0:(len(link)-15)]


client = commands.Bot(command_prefix=get_prefix)
status = ["Bean Jam #" + str(5), "by Bean Devs"]
cycleStatus = iter(status)
client.beanJamCount = 5


@client.event
async def on_ready(): #When bot is on
    await client.change_presence(status=discord.Status.online, activity=discord.Game(status[0]))
    print("--BOT IS ONLINE--")


@client.event
async def on_guild_join(guild):  #When joins a guild
    with open("data.json", "r") as f:
        data = json.load(f)

    data["prefixes"][str(guild.id)] = defaultPrefix

    with open("data.json", "w") as f:
        json.dump(data, f, indent=4)


@client.event
async def on_guild_remove(guild):  #When removes from a guild
    with open("dats.json", "r") as f:
        data = json.load(f)

    data["prefixes"].pop(str(guild.id))

    with open("data.json", "w") as f:
        json.dump(data, f, indent=4)


@client.command()
@commands.has_permissions(administrator=True) #User must have administrator permission
async def changePrefix(ctx, prefix=None): #changes prefix
    with open("data.json", "r") as f:
        data = json.load(f)

    oldPrefix = data["prefixes"][str(ctx.guild.id)]
    if(prefix):
        data["prefixes"][str(ctx.guild.id)] = str(prefix)
    else:
        data["prefixes"][str(ctx.guild.id)] = defaultPrefix
        prefix = defaultPrefix

    with open("data.json", "w") as f:
        json.dump(data, f, indent=4)

    embed = discord.Embed(
        colour=embedColor
    )
    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="Prefix Changed", value=f"Prefix has been changed \"{oldPrefix}\" to \"{prefix}\".", inline=False)

    await ctx.send(embed=embed)


@client.command()
async def time(ctx):  #sends today's date
    now = datetime.utcnow()
    embed = discord.Embed(
        colour=embedColor
    )
    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="Today's Date (GMT)",value=f"{now.year}-{now.month}-{now.day}\n{now.hour}:{now.minute}:{now.second}", inline=False)

    await ctx.send(embed=embed)


@client.command()
async def localTime(ctx):  #sends today's date
    now = datetime.now()
    embed = discord.Embed(
        colour=embedColor
    )
    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="Today's Date (Local)",value=f"{now.year}-{now.month}-{now.day}\n{now.hour}:{now.minute}:{now.second}", inline=False)

    await ctx.send(embed=embed)


@client.command()
async def latency(ctx): #sends latency
    embed = discord.Embed(
        colour=embedColor
    )
    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="Latency", value=f"{round(client.latency * 1000)}ms", inline=False)

    await ctx.send(embed=embed)


@client.command()
async def credits(ctx): #sends credits
    embed = discord.Embed(
        colour=embedColor
    )
    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="Credits", value=botCredits, inline=False)

    await ctx.send(embed=embed)


@client.command()
@commands.has_permissions(kick_members=True) #User must have kick members permission
async def kick(ctx,member:discord.Member,*,reason=None): #kicks
    await member.kick(reason=reason)
    if(reason):
        embed = discord.Embed(
            colour=embedColor
        )

        avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
        embed.set_author(name=ctx.author.name,
                         icon_url=avatarUrl)
        embed.add_field(name="User Kicked", value=f"{member} has been kicked successfully. The reason is \"{reason}\".", inline=False)

        await ctx.send(embed=embed)

    else:
        embed = discord.Embed(
            colour=embedColor
        )

        avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
        embed.set_author(name=ctx.author.name,
                         icon_url=avatarUrl)
        embed.add_field(name="User Kicked", value=f"{member} has been kicked successfully.",inline=False)

        await ctx.send(embed=embed)


@client.command()
@commands.has_permissions(ban_members=True) #User must have ban members permission
async def ban(ctx,member:discord.Member,*,reason=None): #bans
    await member.ban(reason=reason)
    if(reason):
        embed = discord.Embed(
            colour=embedColor
        )

        avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
        embed.set_author(name=ctx.author.name,
                         icon_url=avatarUrl)
        embed.add_field(name="User Banned", value=f"{member} has been banned successfully. The reason is \"{reason}\".", inline=False)

        await ctx.send(embed=embed)

    else:
        embed = discord.Embed(
            colour=embedColor
        )

        avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
        embed.set_author(name=ctx.author.name,
                         icon_url=avatarUrl)
        embed.add_field(name="User Banned", value=f"{member} has been banned successfully.",inline=False)

        await ctx.send(embed=embed)


@client.command()
@commands.has_permissions(ban_members=True) #User must have ban members permission
async def unban(ctx, *, member): #unbans
    banned_users = await ctx.guild.bans()

    member_name, member_discriminator = member.split('#')
    for ban_entry in banned_users:
        user = ban_entry.user

        if (user.name, user.discriminator) == (member_name, member_discriminator):
            await ctx.guild.unban(user)

            embed = discord.Embed(
                colour=embedColor
            )

            avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
            embed.set_author(name=ctx.author.name,
                             icon_url=avatarUrl)
            embed.add_field(name="User Unbanned", value=f"{member} has been unbanned successfully.", inline=False)

            await ctx.send(embed=embed)
            return True

    embed = discord.Embed(
        colour=embedColor
    )

    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="User Already Unbanned", value=f"Couldn't unban {member} because user is already unbanned.", inline=False)

    await ctx.send(embed=embed)


@client.command()
@commands.has_permissions(manage_messages=True) #User must have manage messages permission
async def clean(ctx,amount="1"):
    if(amount.isnumeric() and int(amount) > 0):
        amount = int(amount)
        amount += 1
        await ctx.channel.purge(limit=amount)


@client.command()
@commands.has_permissions(manage_roles=True) #User must have manage role permission
async def giveRole(ctx, member:discord.Member, role:discord.Role):
    await member.add_roles(role)

    embed = discord.Embed(
        colour=embedColor
    )

    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="Give Role", value=f"{member.mention} got the {role.mention} role.", inline=False)

    await ctx.send(embed=embed)


@client.command()
@commands.has_permissions(manage_roles=True) #User must have manage role permission
async def removeRole(ctx, member:discord.Member, role:discord.Role):
    await member.remove_roles(role)

    embed = discord.Embed(
        colour=embedColor
    )

    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="Remove Role", value=f"{role.mention} role removed from {member.mention}.", inline=False)

    await ctx.send(embed=embed)


@client.command()
@commands.has_permissions(administrator=True) #User must have administrator permission
async def changeNickname(ctx, member:discord.Member, newName):
    oldName = member.display_name

    await member.edit(nick=newName)

    embed = discord.Embed(
        colour=embedColor
    )

    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="Change Nickname", value=f"Nickname of {member.mention} has been changed **\"{oldName}\"** to **\"{newName}\"**.", inline=False)

    await ctx.send(embed=embed)


@client.command()
async def dm(ctx,user:discord.User,*,msg):
    embedDM = discord.Embed(
        colour=embedColor
    )

    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embedDM.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embedDM.add_field(name="DM",
                    value=msg,
                    inline=False)

    embed = discord.Embed(
        colour=embedColor
    )

    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="DM",
                    value=f"Directly messaged to {user.mention}. Message will be delivered if the user accepts direct messages.",
                    inline=False)

    await ctx.send(embed=embed)
    await user.send(embed=embedDM)


@client.command()
async def anonymDm(ctx,user:discord.User,*,msg):
    embedDM = discord.Embed(
        colour=embedColor
    )

    avatarUrl = GetAvatarLink(str(client.user.avatar_url))
    embedDM.set_author(name=client.user.name,
                       icon_url=avatarUrl)
    embedDM.add_field(name="DM",
                      value=msg,
                      inline=False)

    embed = discord.Embed(
        colour=embedColor
    )

    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="DM",
                    value=f"Directly and anonymously messaged to {user.mention}. Message will be delivered if the user accepts direct messages.",
                    inline=False)

    await ctx.send(embed=embed)
    await user.send(embed=embedDM)


@client.event
async def on_command_error(ctx,error):
    if(isinstance(error, commands.CommandNotFound)): #When a command not found
        embed = discord.Embed(
            colour=embedColor
        )

        avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
        embed.set_author(name=ctx.author.name,
                         icon_url=avatarUrl)
        embed.add_field(name="Command Not Found", value=f"Are you sure there is a command like this?",inline=False)

        await ctx.send(embed=embed)


@client.command()
async def say(ctx,*,msg=None): #says msg
    if(msg):
        await ctx.message.delete()
        embed = discord.Embed(
            colour=embedColor
        )

        avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
        embed.set_author(name=ctx.author.name,
                         icon_url=avatarUrl)
        embed.add_field(name="Saying", value=msg, inline=False)

        await ctx.send(embed=embed)


@client.command()
async def getBeanJamRole(ctx, num): #gives the bean jam role
    if(num.isnumeric() and int(num) <= client.beanJamCount and int(num) > 0):
        guild = ctx.guild
        role = get(guild.roles, name=f"#BeanJam{num}")
        if (role == None):
            role = await guild.create_role(name=f"#BeanJam{num}")

        await ctx.author.add_roles(role)

        embed = discord.Embed(
            colour=embedColor
        )

        avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
        embed.set_author(name=ctx.author.name,
                         icon_url=avatarUrl)
        embed.add_field(name="Get Bean Jam Role", value=f"You got the {role.mention} role.", inline=False)

        await ctx.send(embed=embed)


@client.command()
async def generateTheme(ctx):
    theme = ReturnRandomTheme()

    embed = discord.Embed(
        colour=embedColor
    )

    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="Theme", value=theme, inline=False)

    await ctx.send(embed=embed)


@client.command()
async def beanJamDate(ctx):
    text = "Every Sunday 14:00 (GMT)"

    embed = discord.Embed(
        colour=embedColor
    )

    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="Bean Jam Date", value=text, inline=False)

    await ctx.send(embed=embed)


@client.command()
async def joinBeanJam(ctx):
    text = "To join Bean Jam join our Discord Server: https://discord.gg/8jcNWqeQgQ"

    embed = discord.Embed(
        colour=embedColor
    )

    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="Join Bean Jam", value=text, inline=False)

    await ctx.send(embed=embed)


@client.command()
async def about(ctx):
    text = "Simple bot for Bean Jam and small tasks. Use the **\"help\"** command for help."

    embed = discord.Embed(
        colour=embedColor
    )

    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="About", value=text, inline=False)

    await ctx.send(embed=embed)


@client.command()
async def source(ctx):
    text = "Source Code: https://github.com/chivenos/beanbot."

    embed = discord.Embed(
        colour=embedColor
    )

    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="Source", value=text, inline=False)

    await ctx.send(embed=embed)


async def bean_jam_notifications(): #Bean Jam notifications
    while True:
        now = datetime.utcnow()
        if(now.weekday() == beanJamStartDate[0] and now.hour == beanJamStartDate[1] and now.minute == beanJamStartDate[2]): #bean jam started
            with open("data.json", "r") as f:
                data = json.load(f)

            for key,channelId in data["BeanJamNotificationChannels"].items():
                if(channelId != ""):
                    guild = client.get_guild(int(key))
                    role = get(guild.roles, name=f"#BeanJam{client.beanJamCount}")
                    if(role == None):
                        role = await guild.create_role(name=f"#BeanJam{client.beanJamCount}")

                    channel = client.get_channel(int(channelId))

                    embed = discord.Embed(
                        colour=embedColor
                    )

                    avatarUrl = GetAvatarLink(str(client.user.avatar_url))
                    embed.set_author(name=client.user.name,
                                     icon_url=avatarUrl)
                    embed.add_field(name="Bean Jam Notification",
                                    value=f"**Bean Jam #{client.beanJamCount}** has been started!", inline=False)

                    await guild.create_role(name=f"#BeanJam{client.beanJamCount + 1}")

                    await channel.send(role.mention)
                    await channel.send(embed=embed)

            client.beanJamCount += 1

        elif(now.weekday() == beanJamReminderDate[0] and now.hour == beanJamReminderDate[1] and now.minute == beanJamReminderDate[2]): #bean jam starting in an hour
            with open("data.json", "r") as f:
                data = json.load(f)

            for key,channelId in data["BeanJamNotificationChannels"].items():
                if(channelId != ""):
                    guild = client.get_guild(int(key))
                    role = get(guild.roles, name=f"#BeanJam{client.beanJamCount}")
                    if(role == None):
                        role = await guild.create_role(name=f"#BeanJam{client.beanJamCount}")

                    channel = client.get_channel(int(channelId))

                    embed = discord.Embed(
                        colour=embedColor
                    )

                    avatarUrl = GetAvatarLink(str(client.user.avatar_url))
                    embed.set_author(name=client.user.name,
                                     icon_url=avatarUrl)
                    embed.add_field(name="Bean Jam Notification",
                                    value=f"**Bean Jam #{client.beanJamCount}** is starting in an hour!", inline=False)

                    await channel.send(role.mention)
                    await channel.send(embed=embed)

        elif (now.weekday() == beanJamThemeDate[0] and now.hour == beanJamThemeDate[1] and now.minute == beanJamThemeDate[2]):  #bean jam theme announced
            with open("data.json", "r") as f:
                data = json.load(f)

            theme = ReturnRandomTheme()

            for key, channelId in data["BeanJamNotificationChannels"].items():
                if (channelId != ""):
                    guild = client.get_guild(int(key))
                    role = get(guild.roles, name=f"#BeanJam{client.beanJamCount}")
                    if(role == None):
                        role = await guild.create_role(name=f"#BeanJam{client.beanJamCount}")

                    channel = client.get_channel(int(channelId))

                    embed = discord.Embed(
                        colour=embedColor
                    )

                    avatarUrl = GetAvatarLink(str(client.user.avatar_url))
                    embed.set_author(name=client.user.name,
                                     icon_url=avatarUrl)
                    embed.add_field(name="Bean Jam Notification",
                                    value=f"The theme of **Bean Jam #{client.beanJamCount}** is **\"{theme}\"**!", inline=False)

                    await channel.send(role.mention)
                    await channel.send(embed=embed)

        elif (now.weekday() == beanJamRoleDate[0] and now.hour == beanJamRoleDate[1] and now.minute == beanJamRoleDate[2]):  #bean jam role released
            with open("data.json", "r") as f:
                data = json.load(f)

            for key, channelId in data["BeanJamNotificationChannels"].items():
                if (channelId != ""):
                    guild = client.get_guild(int(key))
                    channel = client.get_channel(int(channelId))

                    embed = discord.Embed(
                        colour=embedColor
                    )

                    avatarUrl = GetAvatarLink(str(client.user.avatar_url))
                    embed.set_author(name=client.user.name,
                                     icon_url=avatarUrl)
                    embed.add_field(name="Bean Jam Notification",
                                    value=f"Grab your role! To grab it use the \"**_getBeanJamRole {client.beanJamCount}_**\" command.", inline=False) #GRAB YOUR ROLE LLLLLLLLL

                    await channel.send(guild.default_role)
                    await channel.send(embed=embed)

        await asyncio.sleep(beanJamNotificationsLoopInterval)

client.loop.create_task(bean_jam_notifications())


@client.command()
@commands.has_permissions(administrator=True) #User must have administrator permission
async def setBeanJamNotificationsChannel(ctx,channel):
    if(channel[1] == "#"):
        channel = channel[2:-1]
        with open("data.json", "r") as f:
            data = json.load(f)

        data["BeanJamNotificationChannels"][str(ctx.guild.id)] = channel

        with open("data.json", "w") as f:
            json.dump(data, f, indent=4)

        channel = client.get_channel(int(channel))

        embed = discord.Embed(
            colour=embedColor
        )

        avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
        embed.set_author(name=ctx.author.name,
                         icon_url=avatarUrl)
        embed.add_field(name="Bean Jam Notification", value=f"Bean Jam Notification Channel Has Been Set As {channel.mention}", inline=False)

        await ctx.send(embed=embed)


@client.command()
@commands.has_permissions(administrator=True) #User must have administrator permission
async def disableBeanJamNotifications(ctx):
    with open("data.json", "r") as f:
        data = json.load(f)

    data["BeanJamNotificationChannels"].pop(str(ctx.guild.id))

    with open("data.json", "w") as f:
        json.dump(data, f, indent=4)

    embed = discord.Embed(
        colour=embedColor
    )

    avatarUrl = GetAvatarLink(str(ctx.author.avatar_url))
    embed.set_author(name=ctx.author.name,
                     icon_url=avatarUrl)
    embed.add_field(name="Bean Jam Notification",
                    value=f"Bean Jam notifications has been disabled.", inline=False)

    await ctx.send(embed=embed)



"""#EMBED TEMPLATE
    embed = discord.Embed(
        title="Title",
        description="This is a description",
        colour=embedColor
    )

    embed.set_footer(text="This is a footer.")
    embed.set_image(url="https://cdn.discordapp.com/attachments/520265639680671747/533389224913797122/rtgang.jpeg")
    embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/520265639680671747/533389224913797122/rtgang.jpeg")
    embed.set_author(name="Author Name",
                     icon_url="https://cdn.discordapp.com/attachments/520265639680671747/533389224913797122/rtgang.jpeg")
    embed.add_field(name="Field Name", value="Field Value", inline=False)
    embed.add_field(name="Field Name", value="Field Value", inline=True)
    embed.add_field(name="Field Name", value="Field Value", inline=True)

    await ctx.send(embed=embed)
"""

# ----
client.run(token)